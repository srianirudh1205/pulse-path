import React, { useState, useEffect, useCallback } from 'react';
import { ShieldAlert, RefreshCcw, Map, ArrowLeft, Activity, Heart, Flame, Baby, Phone, Navigation, Clock, MapPin, Gauge, Loader2, MapPinOff, AlertCircle, Truck, Car, User, ShieldCheck } from 'lucide-react';

// --- HOOKS ---
const useGeolocation = () => {
  const [location, setLocation] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const getLocation = useCallback(() => {
    setLoading(true); setError(null);
    if (!navigator.geolocation) { setError('Geolocation not supported'); setLoading(false); return; }
    navigator.geolocation.getCurrentPosition(
      (p) => { setLocation({ lat: p.coords.latitude, lng: p.coords.longitude }); setLoading(false); },
      (e) => { setError('GPS Error'); setLoading(false); },
      { enableHighAccuracy: true, timeout: 20000 }
    );
  }, []);
  return { location, error, loading, getLocation };
};

const useHospitalSearch = () => {
  const [hospitals, setHospitals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const searchHospitals = useCallback(async (loc, type) => {
    if (!loc || !type) return;
    setLoading(true); setError(null);
    try {
      const q = `[out:json];node["amenity"="hospital"](around:15000,${loc.lat},${loc.lng});out;`;
      const res = await fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(q)}`);
      const data = await res.json();
      const results = (data.elements || []).map(n => {
        const d = Math.sqrt(Math.pow(n.lat - loc.lat, 2) + Math.pow(n.lon - loc.lng, 2)) * 111;
        return { id: n.id.toString(), name: n.tags.name || "Hospital", vicinity: n.tags['addr:street'] || "Nearby", location: { lat: n.lat, lng: n.lon }, distance: d.toFixed(1), eta: Math.round(d * 4 + 5), traffic_status: d > 5 ? 'Moderate' : 'Clear' };
      });
      results.sort((a, b) => a.distance - b.distance);
      setHospitals(results.slice(0, 3));
    } catch (e) { setError('Search Error'); } finally { setLoading(false); }
  }, []);
  return { hospitals, loading, error, searchHospitals };
};

// --- COMPONENTS ---
const SOSButton = ({ onClick }) => (
  <div className="flex flex-col items-center p-8">
    <button onClick={onClick} className="w-48 h-48 rounded-full bg-red-600 text-white font-bold text-2xl shadow-xl active:scale-95 animate-pulse flex flex-col items-center justify-center">
      <AlertCircle size={64} className="mb-2" /> <span>SOS</span>
    </button>
  </div>
);

const EmergencyType = ({ onSelect }) => {
  const types = [{ id: 'accident', label: 'Accident', icon: <Activity />, color: 'red' }, { id: 'cardiac', label: 'Cardiac', icon: <Heart />, color: 'rose' }, { id: 'burn', label: 'Burn', icon: <Flame />, color: 'orange' }, { id: 'pregnancy', label: 'Pregnancy', icon: <Baby />, color: 'purple' }];
  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-2xl font-bold">What is happening?</h2>
      <div className="grid grid-cols-2 gap-4">
        {types.map(t => (
          <button key={t.id} onClick={() => onSelect(t.id)} className="p-6 bg-white border-2 rounded-2xl flex flex-col items-center">
            <div className={`p-4 bg-${t.color}-50 text-${t.color}-600 rounded-xl mb-3`}>{t.icon}</div>
            <h3 className="font-bold">{t.label}</h3>
          </button>
        ))}
      </div>
    </div>
  );
};

const AmbulanceTracker = ({ onContinue }) => {
  const [amb, setAmb] = useState(null);
  useEffect(() => {
    fetch('http://10.1.6.76:3001/api/ambulance/find').then(r => r.json()).then(setAmb);
  }, []);
  if (!amb) return <div className="p-12 text-center font-bold">Locating Ambulance...</div>;
  return (
    <div className="bg-white rounded-2xl shadow-xl border p-6">
      <h3 className="text-2xl font-black mb-4">Ambulance: {amb.ambulance_id}</h3>
      <p className="font-bold mb-6">Driver: {amb.driver_name} ({amb.eta_mins}m away)</p>
      <a href={`tel:${amb.driver_phone}`} className="w-full bg-green-500 text-white p-4 rounded-xl flex items-center justify-center gap-2 font-bold mb-4">
        <Phone size={20} /> Call Driver
      </a>
      <button onClick={onContinue} className="w-full bg-black text-white p-4 rounded-xl font-bold">Track to Hospital</button>
    </div>
  );
};

const HospitalCard = ({ hospital }) => (
  <div className="bg-white rounded-2xl shadow-sm p-5 mb-4 border">
    <div className="flex justify-between items-start mb-3">
      <h3 className="text-xl font-bold">{hospital.name}</h3>
      <div className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-black">{hospital.eta}m</div>
    </div>
    <div className="flex gap-3 mt-4">
      <button onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&destination=${hospital.location.lat},${hospital.location.lng}&travelmode=driving&dir_action=navigate`, '_blank')} className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold">Navigate</button>
    </div>
  </div>
);

// --- MAIN APP ---
export default function App() {
  const { location, error: geoError, loading: geoLoading, getLocation } = useGeolocation();
  const { hospitals, error: searchError, loading: searchLoading, searchHospitals } = useHospitalSearch();
  const [step, setStep] = useState('sos');
  const [emergencyType, setEmergencyType] = useState(null);

  const handleSOS = () => { setStep('type'); getLocation(); };
  const handleTypeSelect = (t) => { setEmergencyType(t); setStep('ambulance'); };
  
  useEffect(() => { if (location && step === 'results') searchHospitals(location, emergencyType); }, [location, step]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center">
      <header className="w-full bg-white border-b py-4 px-6 flex justify-between">
        <div className="flex items-center gap-2 text-red-600 font-black text-xl"><ShieldAlert /> PULSEPATH</div>
        {step !== 'sos' && <button onClick={() => window.location.reload()} className="text-xs font-bold uppercase">Reset</button>}
      </header>
      <main className="w-full max-w-md px-6 py-8">
        {step === 'sos' && <SOSButton onClick={handleSOS} />}
        {step === 'type' && <EmergencyType onSelect={handleTypeSelect} />}
        {step === 'ambulance' && <AmbulanceTracker onContinue={() => setStep('results')} />}
        {step === 'results' && (
          <div>
            {(geoLoading || searchLoading) ? <div className="p-12 text-center">Finding Route...</div> : hospitals.map(h => <HospitalCard key={h.id} hospital={h} />)}
          </div>
        )}
      </main>
    </div>
  );
}
