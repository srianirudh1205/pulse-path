require('dotenv').config({ path: '../sos-connector/.env' });
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3001;

// Database of hospitals in the SRM AP / Amaravati Region
const ALL_HOSPITALS = [
  {
    id: "hosp-1",
    name: "NRI General Hospital",
    vicinity: "Mangalagiri Road, Chinakakani",
    phone: "+91 86452 36777",
    specialties: ['accident', 'cardiac', 'burn', 'pregnancy'],
    base_dist: 8.5
  },
  {
    id: "hosp-2",
    name: "Manipal Hospital Vijayawada",
    vicinity: "Near Varadhi, Tadepalle",
    phone: "+91 86624 53333",
    specialties: ['cardiac', 'accident'],
    base_dist: 12.2
  },
  {
    id: "hosp-3",
    name: "AIMS Mangalagiri",
    vicinity: "Mangalagiri, Guntur",
    phone: "+91 86452 46300",
    specialties: ['pregnancy', 'accident'],
    base_dist: 6.1
  },
  {
    id: "hosp-4",
    name: "SRM University Health Center",
    vicinity: "SRM University AP Campus",
    phone: "+91 86323 43000",
    specialties: ['accident', 'burn'],
    base_dist: 0.5
  },
  {
    id: "hosp-5",
    name: "Ramesh Hospitals",
    vicinity: "Guntur Road, Vijayawada",
    phone: "+91 86624 88888",
    specialties: ['cardiac', 'accident'],
    base_dist: 15.8
  }
];

app.get('/api/hospitals', (req, res) => {
  const { lat, lng, type } = req.query;
  
  // 1. Filter Suitable Hospitals
  let filtered = ALL_HOSPITALS.filter(h => h.specialties.includes(type));
  
  // 2. Traffic & Route Analysis (Mocked)
  // Distance + Traffic Delay = ETA
  const results = filtered.map(h => {
    const trafficDelay = Math.floor(Math.random() * 10); // 0-10 mins delay
    const distance = h.base_dist + (Math.random() * 2); // Vary distance slightly
    const eta = Math.round((distance * 3) + trafficDelay); // 3 mins per km approx

    return {
      ...h,
      distance: distance.toFixed(1),
      eta: eta,
      traffic_status: trafficDelay > 7 ? 'Heavy' : (trafficDelay > 3 ? 'Moderate' : 'Clear'),
      location: { 
        lat: parseFloat(lat) + (Math.random() * 0.02 - 0.01), 
        lng: parseFloat(lng) + (Math.random() * 0.02 - 0.01) 
      }
    };
  });

  // 3. Select Fastest (Sorted by ETA)
  results.sort((a, b) => a.eta - b.eta);

  console.log(`PulsePath Engine: Analyzed ${results.length} suitable hospitals for ${type}`);
  res.json(results.slice(0, 3));
});

// Mock Ambulance Tracker API
app.get('/api/ambulance/find', (req, res) => {
  res.json({
    ambulance_id: "AMB-7742",
    driver_name: "Rajesh Kumar",
    driver_phone: "+91 90000 11111",
    current_location: { lat: 16.4, lng: 80.5 },
    eta_mins: 8,
    status: "Dispatched"
  });
});

app.listen(PORT, () => {
  console.log(`PulsePath Backend running on http://localhost:${PORT}`);
});
